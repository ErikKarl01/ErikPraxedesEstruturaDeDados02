typedef struct ContaBancaria Contas;

Contas* cria_conta();
void deposita(Contas* conta);
void saca(Contas* conta);
void transfere(Contas* conta_transfere, Contas* conta_recebe);
void saldo(Contas* conta);
void exclui_conta(Contas** conta, int* numcli, int indice);