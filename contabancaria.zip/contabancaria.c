#include <stdio.h>
#include <stdlib.h>
#include "contabancaria.h"

struct ContaBancaria
{
    char titular[81];
    int numero;
    float saldo;
};

Contas* cria_conta()
{
    Contas* conta = (Contas*)malloc(sizeof(Contas));
    printf("Escolha um titular: \n");
    scanf(" %[^\n]", conta->titular);
    printf("Escolha um numero: \n");
    scanf("%d", &conta->numero);
    printf("Digite o saldo inicial: \n");
    scanf("%f", &conta->saldo);

    return conta;
}

void deposita(Contas* conta)
{
    float deposito;
    printf("Escolha o valor a depositar: \n");
    scanf("%f", &deposito);
    conta->saldo += deposito;
}

void saca(Contas* conta)
{
    float saque;
    printf("Escolha um valor de saque: \n");
    scanf("%f", &saque);
    if (conta->saldo >= saque)
    {
        conta->saldo -= saque;
    }
    else
    {
        printf("Saldo inuficiente!\n");
    }
    
}

void transfere(Contas* conta_transfere, Contas* conta_recebe)
{
    float transferir;
    printf("Escolha um valor de transferência: \n");
    scanf("%f", &transferir);
    if (conta_transfere->saldo >= transferir)
    {
        conta_transfere->saldo -= transferir;
        conta_recebe->saldo += transferir;
    }
    else
    {
        printf("Saldo inuficiente!\n");
    }
}

void saldo(Contas* conta)
{
    printf("Saldo: %.3f\n", conta->saldo);
}

void exclui_conta(Contas** conta, int* numcli, int indice)
{
    int i = indice;
    free(conta[indice]);
    
    for (i = indice; conta[i] != '\0'; i++)
    {
        conta[i] = conta[i+1];
    }
    numcli--;
}
