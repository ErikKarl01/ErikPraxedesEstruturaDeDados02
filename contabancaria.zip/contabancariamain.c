#include "contabancaria.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int numClientes = 1;
struct ContaBancaria
{
    char titular[81];
    int numero;
    float saldo;
};

int pesquisa_conta(Contas** contasBancarias, int numClientes)
{
    int i;
    char nome[81];
    if (contasBancarias == NULL)
    {
        printf("Ninguêm cadastrado!");
        return -1;
    }
    else
    {
        printf("Escolha um nome: \n");
        scanf(" %[^\n]", nome);
        for (i = 0; i < numClientes; i++)
        {
            if (strcmp(contasBancarias[i]->titular,nome) == 0)
            {
                return i;
            }
        }
        printf("Conta não encontrada!\n");
        return -1;
        
    }
    

}


void menu(Contas** contasBancarias, int numClientes)
{
    numClientes = 1;

    int escolha_operacao = 0;
    while (1)
    {
        printf("Escolha qual operação deseja realizar (1 para criar conta, 2 para realizar deposito, 3 para sacar, \
        4 para realizar transferesncia, 5 para exibir saldo, 6 para excluir conta e 7 para finalizar operaçoes!\n)");
        scanf("%d", &escolha_operacao);

        switch (escolha_operacao)
        {
        case (1):
        {
            contasBancarias = realloc(contasBancarias, numClientes*sizeof(Contas*));
            if (contasBancarias == NULL)
            {
                printf("Erro de alocação!");
                exit(1);
            }
            
            contasBancarias[numClientes-1] = cria_conta();
            numClientes++;
            break;
        }
        case (2):
        {
            int result = pesquisa_conta(contasBancarias, numClientes);
            if (result == -1)
            {
                break;
            }
            else
            {
                deposita(contasBancarias[pesquisa_conta(contasBancarias, numClientes)]);
                break;
            }
        }
        case (3):
        {
            if (pesquisa_conta(contasBancarias, numClientes) == -1)
            {
                break;
            }
            else
            {
                saca(contasBancarias[pesquisa_conta(contasBancarias, numClientes)]);
                break;
            }
        }
        case (4):
        {
            if (pesquisa_conta(contasBancarias, numClientes) == -1)
            {
                break;
            }
            else
            {
                printf("Pagador: \n");
                Contas* conta1 = contasBancarias[pesquisa_conta(contasBancarias, numClientes)];
                printf("Recebedor: \n");
                Contas* conta2 = contasBancarias[pesquisa_conta(contasBancarias, numClientes)];
                transfere(conta1, conta1);

                free(conta1);
                free(conta2);
                break;
            }
        }
        case (5):
        {
            if (pesquisa_conta(contasBancarias, numClientes) == -1)
            {
                break;
            }
            else
            {
                saldo(contasBancarias[pesquisa_conta(contasBancarias, numClientes)]);
                break;
            }

            break;
        }
        case (6):
        {
            if (pesquisa_conta(contasBancarias, numClientes) == -1)
            {
                break;
            }
            else
            {
                int indice = pesquisa_conta(contasBancarias, numClientes);
                exclui_conta(contasBancarias, &numClientes, indice);
                break;
            }

            break;
            break;
        }
        case (7):
        {
            exit(0);

            break;
        }
        
        default:
            printf("Opção inválida!");
            break;
        }
    }
    
}


int main(void)
{
    Contas** contasBancarias = NULL;
    menu(contasBancarias, numClientes);
    free(contasBancarias);
    return 0;
}