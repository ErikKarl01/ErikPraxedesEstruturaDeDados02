#include "Aluno.h"
#include <string.h>

Aluno *cria_aluno(char nome[], int matricula)
{
    Aluno *aluno = (Aluno*)malloc(sizeof(Aluno));

    aluno->matricula = matricula;
    strcpy(aluno->nome, nome);

    return aluno;
}

void matricula_disciplina(Aluno *aluno, Disciplina *disciplina)
{
    if (aluno->num_disciplinas<10)
    {
        char nome[100];
        int i;
        aluno->num_disciplinas++;
        printf("Qual diciplina deseja cadastrar? \n");
        scanf("%s", nome);
        for (i = 0; i < aluno->num_disciplinas; i++)
        {
            if (strcmp(disciplina[i].nome, nome) == 0)
            {
                aluno->disciplinas[aluno->num_disciplinas-1] = disciplina[i];
                return;
            }
            
        }
        
    }
    return;

}


void exclui_aluno(Aluno *aluno)
{
    int i;
    char nome[100];
    printf("Escolha a disciplina que deseja excluir: \n");
    scanf("%s", nome);

    for (i = 0; i < 10; i++)
    {
        if (strcmp(aluno[i].nome, nome) == 0)
        {
            free(&aluno[i]);
        }
    } 
}