#include "Aluno.h"


void menu(Aluno* aluno, int* qtalunos, Disciplina *diciplina, int *qtdiciplina)
{
    int escolha;
    char nome_aluno[100];
    int matricula;
    char nome_diciplina[100];
    int codigo;

    printf("Escolha: \n");
    scanf("%d", &escolha);

    switch (escolha)
    {
    case 1:
        printf("Nome: \n");
        scanf(" %[^\n]", nome_aluno);
        printf("Matricula: \n");
        scanf("%d", &matricula);
        (*qtalunos)++;
        aluno = realloc(aluno, *qtalunos*sizeof(Aluno*));
        aluno[*qtalunos - 1] =  *cria_aluno(nome_aluno, matricula);
        break;

    case 2:
        printf("Nome: \n");
        scanf(" %[^\n]", nome_diciplina);
        printf("Codigo: \n");
        scanf("%d", &codigo);
        (*qtdiciplina)++;
        diciplina = realloc(diciplina, *qtdiciplina*sizeof(diciplina));
        diciplina[*qtdiciplina - 1] = *cria_disciplina(nome_diciplina, codigo);

        break;

    case 3:
        exclui_disciplina(diciplina);
        (*qtdiciplina)--;
        diciplina = realloc(diciplina, *(qtdiciplina)*sizeof(Disciplina));
        break;
    
    case 4:
        exclui_aluno(aluno);
        (*qtalunos)--;
        aluno = realloc(aluno, *(qtalunos)*sizeof(Disciplina));
        break;
    
    case 5:
        if(diciplina!=NULL)
        matricula_disciplina(aluno, diciplina);
        else
        printf("Não há diciplinas existentes!\n");
        break;
    
    default:
        printf("Opção inválida");
        break;
    }
}


int main(void)
{
    int qtalunos = 0;
    int qtdiciplina = 0;
    Aluno *aluno = NULL;
    Disciplina *diciplina = NULL;
    menu(aluno, &qtalunos, diciplina, &qtdiciplina);
    free(aluno);
    return 0;
}