#include <stdio.h>
#include <stdlib.h>
#include "Disciplina.h"

struct Disciplina
{
    char nome[100];
    int codigo;
};

Disciplina *cria_disciplina(char nome[], int codigo)
{
    Disciplina *diciplina = (Disciplina*)malloc(sizeof(Disciplina));
   
    diciplina->codigo = codigo;
    strcpy(diciplina->nome, nome);

    return diciplina;
}

void exclui_disciplina(Disciplina* diciplina)
{
    int i;
    char nome[100];
    printf("Escolha a disciplina que deseja excluir: \n");
    scanf("%s", nome);

    for (i = 0; i < 10; i++)
    {
        if (strcmp(diciplina[i].nome, nome) == 0)
        {
            int j = 0;
            free(&diciplina[i]);
        }
    }  
}

