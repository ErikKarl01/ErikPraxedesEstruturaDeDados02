#include <stdio.h>
#include <stdlib.h>



typedef struct Disciplinas Disciplina;
struct Disciplinas
{
    char nome[100];
    int codigo;
};

Disciplina* cria_disciplina(char nome[], int codigo);
void exclui_disciplina(Disciplina* disciplina);