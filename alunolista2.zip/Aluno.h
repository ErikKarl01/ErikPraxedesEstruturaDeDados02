#include "Disciplina.h"

typedef struct Alunos Aluno;

struct Alunos
{
    char nome[100];
    int matricula;
    Disciplina disciplinas[10];
    int num_disciplinas;
};

Aluno *cria_aluno(char nome[], int matricula);

void matricula_disciplina(Aluno* aluno, Disciplina* disciplina);

void exclui_aluno(Aluno* aluno);

